import java.util.Scanner;

public class RockPaperScissors {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int computerChoice = (int) (Math.random() * 3); // Random number between 0 and 2

        // Prompt user for input either rock or paper or scissors
        System.out.print("Pick one Rock:0, Paper:1, Scissors:2 -> ");
        int userChoice = input.nextInt();

        // Show choices for user and computer
        System.out.println("You: " + userChoice);
        System.out.println("Computer: " + computerChoice);

        // Figure out who won
        if (userChoice == computerChoice) {
            System.out.println("It's a tie!");
        } else if ((userChoice == 0 && computerChoice == 2) || 
                   (userChoice == 1 && computerChoice == 0) || 
                   (userChoice == 2 && computerChoice == 1)) {
            System.out.println("You Win!");
        } else {
            System.out.println("Computer Wins!");
        }

        input.close();
    }
}
